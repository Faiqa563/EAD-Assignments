export const QuizData = [
    {
        id: 0,
        question: "What is the capital of Pakistan?",
        options: [ "Karachi",
         "Islamabad",
        "Lahore",
        "None"],
       
        answer: "Islamabad"
    },
    {
        id: 0,
        question: "Where is the Cricket National Stadium?",
        options: ["Islamabad","Gawader", "Lahore",  "Karachi"],

        answer:   "Karachi"
    },
    {
        id: 0,
        question:  "Which of the following building is the largest in Pakistan",
        options: [ "Bahria Icon Tower",
         "Chapal Skymark",
        "Dolmen Tower",
         "MCB Tower"],
        answer: "Bahria Icon Tower"
    },
    {
        id: 0,
        question: "Karakoram Highway is the highest road ever built?",
        options: ["True","false"],
        answer: "True"
    },
    {
        id: 0,
        question: "Pakistan’s Sialkot produces over half the world’s footballs?",
        options: ["True","false"],
        answer: "True"
    },
]